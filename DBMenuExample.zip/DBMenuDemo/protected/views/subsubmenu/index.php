<?php
/* @var $this SubsubmenuController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Subsubmenus',
);

$this->menu=array(
	array('label'=>'Create Subsubmenu', 'url'=>array('create')),
	array('label'=>'Manage Subsubmenu', 'url'=>array('admin')),
);
?>

<h1>Subsubmenus</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
