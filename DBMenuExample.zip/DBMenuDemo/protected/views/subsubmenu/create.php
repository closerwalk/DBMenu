<?php
/* @var $this SubsubmenuController */
/* @var $model Subsubmenu */

$this->breadcrumbs=array(
	'Subsubmenus'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Subsubmenu', 'url'=>array('index')),
	array('label'=>'Manage Subsubmenu', 'url'=>array('admin')),
);
?>

<h1>Create Subsubmenu</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>