<?php
/* @var $this SubsubmenuController */
/* @var $model Subsubmenu */

$this->breadcrumbs=array(
	'Subsubmenus'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List Subsubmenu', 'url'=>array('index')),
	array('label'=>'Create Subsubmenu', 'url'=>array('create')),
	array('label'=>'View Subsubmenu', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage Subsubmenu', 'url'=>array('admin')),
);
?>

<h1>Update Subsubmenu <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>