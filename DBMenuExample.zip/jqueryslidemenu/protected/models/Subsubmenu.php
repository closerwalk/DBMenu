<?php

/**
 * This is the model class for table "subsubmenu".
 *
 * The followings are the available columns in table 'subsubmenu':
 * @property integer $id
 * @property string $label
 * @property string $view
 * @property string $url
 * @property integer $position
 * @property integer $visibility
 * @property integer $sub_menu_id
 */
class Subsubmenu extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return Subsubmenu the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'subsubmenu';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('label, view, url, position, visibility, sub_menu_id', 'required'),
			array('position, visibility, sub_menu_id', 'numerical', 'integerOnly'=>true),
			array('label', 'length', 'max'=>70),
			array('view, url', 'length', 'max'=>255),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, label, view, url, position, visibility, sub_menu_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
                    'submenu' => array(self::BELONGS_TO,'Submenu','sub_menu_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'label' => 'Label',
			'view' => 'View',
			'url' => 'Url',
			'position' => 'Position',
			'visibility' => 'Visibility',
			'sub_menu_id' => 'Sub Menu',
		);
	}
           
	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('label',$this->label,true);
		$criteria->compare('view',$this->view,true);
		$criteria->compare('url',$this->url,true);
		$criteria->compare('position',$this->position);
		$criteria->compare('visibility',$this->visibility);
		$criteria->compare('sub_menu_id',$this->sub_menu_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}